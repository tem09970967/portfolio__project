# money-landing

clone project -> cd money-landing -> yarn -> yarn dev
